const Post = require('../../ihub-connect-fe-mvp/backend/models/PostModel');

const postController = {
  createPost: async (req, res) => {
    const newPost = new Post(req.body);
    try {
      const savedPost = await newPost.save();
      res.status(201).json(savedPost);
    } catch (err) {
      res.status(500).json(err);
    }
  },

  likeOrDislikePost: async (req, res) => {
    const postId = req.params.postId;
    const action = req.body.action; // 'like' or 'dislike'

    try {
      const post = await Post.findById(postId);

      if (!post) {
        return res.status(404).json({ error: 'Post not found' });
      }

      if (action === 'like') {
        post.likes += 1;
      } else if (action === 'dislike') {
        post.dislikes += 1;
      } else {
        return res.status(400).json({ error: 'Invalid action' });
      }

      await post.save();
      res.status(200).json(post);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },

  createComment: async (req, res) => {
    const postId = req.params.postId;
    const commentText = req.body.comment;

    try {
      const post = await Post.findById(postId);

      if (!post) {
        return res.status(404).json({ error: 'Post not found' });
      }

      const newComment = {
        userId: req.body.userId,
        comment: commentText,
      };

      post.comments.push(newComment);

      await post.save();
      res.status(201).json(post);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },

  getAllPosts: async (req, res) => {
    try {
      const posts = await Post.find();
      res.status(200).json(posts);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },

  updatePost: async (req, res) => {
    const postId = req.params.postId;
    const updatedData = req.body; // The new data for the post
    try {
      const post = await Post.findByIdAndUpdate(postId, updatedData, { new: true });
      if (!post) {
        return res.status(404).json({ error: 'Post not found' });
      }
      res.status(200).json(post);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },

  updateComment: async (req, res) => {
    const postId = req.params.postId;
    const commentId = req.params.commentId;
    const updatedComment = req.body.comment; // The new comment text

    try {
      const post = await Post.findById(postId);
      if (!post) {
        return res.status(404).json({ error: 'Post not found' });
      }

      const comment = post.comments.id(commentId);
      if (!comment) {
        return res.status(404).json({ error: 'Comment not found' });
      }

      comment.comment = updatedComment;
      await post.save();
      res.status(200).json(post);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },

  deletePost: async (req, res) => {
    const postId = req.params.postId;
    try {
      const deletedPost = await Post.findByIdAndRemove(postId);
      if (!deletedPost) {
        return res.status(404).json({ error: 'Post not found' });
      }
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },

  deleteComment: async (req, res) => {
    const postId = req.params.postId;
    const commentId = req.params.commentId;
    try {
      const post = await Post.findById(postId);
      if (!post) {
        return res.status(404).json({ error: 'Post not found' });
      }

      const comment = post.comments.id(commentId);
      if (!comment) {
        return res.status(404).json({ error: 'Comment not found' });
      }

      comment.remove();
      await post.save();
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },
};

module.exports = postController;
