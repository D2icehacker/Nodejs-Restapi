const SocketIO = require("socket.io");

const initSocketIO = (httpServer) => {
  const io = new SocketIO.Server(httpServer);

  // io.on('connection', (socket) => {
  //     console.log('A user connected');

  //     // Handle socket events here
  //     socket.on('chat message', (msg) => {
  //         io.emit('chat message', msg); // Broadcast the message to everyone
  //     });

  //     socket.on('disconnect', () => {
  //         console.log('User disconnected');
  //     });
  // });

  let onlineUsers = [];

  const addNewUser = (username, socketId) => {
    !onlineUsers.some((user) => user.username === username) &&
      onlineUsers.push({ username, socketId });
  };

  const removeUser = (socketId) => {
    onlineUsers = onlineUsers.filter((user) => user.socketId !== socketId);
  };

  const getUser = (username) => {
    return onlineUsers.find((user) => user.username === username);
  };

  io.on("connection", (socket) => {
    console.log("someone has connected");

    socket.on("newUser", (username) => {
      addNewUser(username, socket.id);
      console.log(onlineUsers.find((user) => user.socketId === socket.id));
    });

    socket.on("addPost", () => {
      io.emit("addPost");
    });

    socket.on("deletePost", () => {
      io.emit("deletePost");
    });

    socket.on("updatePost", () => {
      io.emit("updatePost");
    });

    socket.on("likePost", () => {
      io.emit("likePost");
    });

    socket.on("dislikePost", () => {
      io.emit("dislikePost");
    });

    socket.on("addComment", () => {
      io.emit("addComment");
    });

    socket.on("deleteComment", () => {
      io.emit("deleteComment");
    });

    socket.on("disconnect", () => {
      removeUser(socket.id);
      console.log("someone has disconnected");
    });
  });
};

module.exports = initSocketIO;
