const express = require('express');
const router = express.Router();
const postController = require('../controllers/PostController');
const Post = require('../models/PostModel');

router.post('/posts', postController.createPost);

router.post('/likeOrDislike/:postId', postController.likeOrDislikePost);

router.post('/comment/:postId', postController.createComment);

router.delete('/comment/:postId/:commentId', postController.deleteComment);

router.put('/comment/:postId/:commentId', postController.updateComment);

router.put('/posts/:postId', postController.updatePost);

router.delete('/posts/:postId', postController.deletePost);

router.get('/posts', postController.getAllPosts);

module.exports = router;
