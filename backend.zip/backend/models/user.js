const mongoose = require("mongoose");
const uniqueValidator = require("mongoose-unique-validator");

const userSchema = mongoose.Schema({
name: {type: String },
background: {type: String },
avatar: {type: String },
displayName: { type: String, required: true},
firstName: {type: String},
lastName: {type: String},
gender: {type: String},
departments: {type: Array, default:[]},
units: {type: Array, default:[]},
jobPosition: {type: String},
departments: {type: Array, default:[]},
email: { type: String, required: true, unique: true },
emails: {type: Array, default:[]},
phoneNumbers: {type: Array, default:[]},
address: {type: String},
city: {type: String},
birthday: {type: Date},
aboutMe: {type: String},
password: { type: String, required: true },
});

userSchema.plugin(uniqueValidator);

module.exports = mongoose.model("User", userSchema);
