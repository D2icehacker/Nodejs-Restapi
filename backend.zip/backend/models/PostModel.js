const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({
  userId: String,
  user: {
    name: String,
    avatar: String,
  },
  message: String,
  time: Number,
  type: String,
  media: String,
  visibility: String,
  id: String,
  likes: {
    type: Number,
    default: 0,
  },
  dislikes: {
    type: Number,
    default: 0,
  },
  comments: [
    {
      userId: String,
      comment: String,
    },
  ],
});

module.exports = mongoose.model('Post', postSchema);
